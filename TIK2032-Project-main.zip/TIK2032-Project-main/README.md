# TIK2032-Project
Repositori project TIK2032 - [Gloria Elisabeth Tandi Rondonuwu] [230211060098]
